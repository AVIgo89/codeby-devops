variable "cloud_id" {
  description = "ID   облака в Yandex Cloud"
  type        = string
}

variable "folder_id" {
  description = "ID папки в Yandex Cloud"
  type        = string
}

variable "zone" {
  description = "Зона доступности"
  type        = string
  default     = "ru-central1-a"
}

variable "token" {
  description = "OAuth токен для Yandex Cloud"
  type        = string
  sensitive   = true
}

variable "public_key_path" {
  description = "Путь к публичному SSH-ключу"
  type        = string
  default     = "C:/Users/Дом/.ssh/id_rsa.pub"
}

variable "private_key_path" {
  description = "Путь к  ему приватному SSH-ключу"
  type        = string
  default     = "C:/Users/Дом/.ssh/id_rsa"
}

variable "private_subnet_cidr" {
  description = "CIDR для приватной подсети"
  type        = string
  default     = "192.168.10.0/24"
}

variable "public_subnet_cidr" {
  description = "CIDR для публичной подсети"
  type        = string
  default     = "192.168.20.0/24"
}