terraform {
  required_providers {
    yandex = {
      source = "yandex-cloud/yandex"
    }
  }
}

provider "yandex" {
  cloud_id  = "ajebodsqt71qm8kbauv7"
  folder_id = "b1gnn6lt5mngnvf1vrlq"
  zone      = "ru-central1-b"
  token = "t1.9euelZqaxo2Jjc6anYmWlIzHmZPHyu3rnpWanZCbjI6LyM6OkseUnZ6Kicjl8_daaU0r-e9PC1hm_N3z9xoYSyv5708LWGb81eL17Iac0ZCeiouX0Y-KnZOWnNKMm5Tt-ZCPmpGWm83n9euelZrNyYuOyJyVyMqYmIrPi8eekO_8xeuelZrNyYuOyJyVyMqYmIrPi8eekL3rnpWazpiPjMjOi4-Wy8mZl5GKzc-164ac0ZaektGQj5qRlpvSjJqNiZqN.R8UGJ4-hQUdUuYJsaudvxp00VouwbsBg7ck0WScGEUMtPBE6nIlMUfGaddfKMB6cLPcWmi959XMjT2ScDQjODg"
}

resource "yandex_compute_instance" "my_imported_vm" {
resource "yandex_compute_instance" "my_imported_vm" {
  name        = "vm-for-import"
  platform_id = "standard-v3"
  zone        = "ru-central1-b"

  resources {
    cores  = 2
    memory = 2
  }

  boot_disk {
    auto_delete = true
    device_name = "epd6go5mppodncv0kcme"
    mode        = "READ_WRITE"
    initialize_params {
      # параметры диска
    }
  }

  network_interface {
    index = 0
    subnet_id = "e2lrahn0fpg8vpf35beo"
    nat = true

  }

  metadata = {

  }


}