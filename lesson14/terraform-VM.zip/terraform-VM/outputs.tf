output "vm_public_ip" {
  description = "Public IP of the public VM"
  value       = yandex_compute_instance.vm_public.network_interface[0].nat_ip_address
}

output "vm_public_internal_ip" {
  description = "Internal IP of the public VM"
  value       = yandex_compute_instance.vm_public.network_interface[0].ip_address
}

output "vm_private_internal_ip" {
  description = "Internal IP of the private VM"
  value       = yandex_compute_instance.vm_private.network_interface[0].ip_address
}

output "public_vm_ssh_command" {
  description = "SSH command for public VM"
  value       = "ssh -i ${var.ssh_private_key_path} ubuntu@${yandex_compute_instance.vm_public.network_interface[0].nat_ip_address}"
}

output "private_vm_ssh_command" {
  description = "SSH command for private VM (via bastion)"
  value       = "ssh -i ${var.ssh_private_key_path} -J ubuntu@${yandex_compute_instance.vm_public.network_interface[0].nat_ip_address} ubuntu@${yandex_compute_instance.vm_private.network_interface[0].ip_address}"
}

output "nginx_public_url" {
  description = "URL to access Nginx on public VM"
  value       = "http://${yandex_compute_instance.vm_public.network_interface[0].nat_ip_address}"
}

output "nginx_private_url" {
  description = "URL to access Nginx on private VM (only from internal network)"
  value       = "http://${yandex_compute_instance.vm_private.network_interface[0].ip_address}:8080"
}