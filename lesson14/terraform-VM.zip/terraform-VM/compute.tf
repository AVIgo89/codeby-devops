resource "yandex_compute_instance" "vm_public" {
  name        = "vm-public"
  description = "Public VM with Nginx"
  zone        = var.default_zone
  platform_id = "standard-v3"

  resources {
    cores  = 2
    memory = 2
    core_fraction = 20
  }

  boot_disk {
    initialize_params {
      image_id = var.ubuntu_image_id
      size     = 20
      type     = "network-hdd"
    }
  }

  network_interface {
    subnet_id          = yandex_vpc_subnet.subnet_public.id
    nat                = true
    security_group_ids = [yandex_vpc_security_group.sg_public.id]
  }

  metadata = {
    ssh-keys = "ubuntu:${file(var.ssh_public_key_path)}"
  }

  provisioner "remote-exec" {
    inline = [
      "echo 'Starting Nginx installation...'",
      "sudo apt-get update -y",
      "sudo apt-get install -y nginx",
      "sudo systemctl enable nginx",
      "sudo systemctl start nginx",
      "echo 'Nginx installed successfully!'",
      "curl -s http://localhost | head -5"
    ]

    connection {
      type        = "ssh"
      user        = "ubuntu"
      private_key = file(var.ssh_private_key_path)
      host        = self.network_interface[0].nat_ip_address
    }
  }

  depends_on = [
    yandex_vpc_subnet.subnet_public
  ]
}


resource "yandex_compute_instance" "vm_private" {
  name        = "vm-private"
  description = "Private VM with Nginx"
  zone        = var.default_zone
  platform_id = "standard-v3"

  resources {
    cores  = 2
    memory = 2
    core_fraction = 20
  }

  boot_disk {
    initialize_params {
      image_id = var.ubuntu_image_id
      size     = 20
      type     = "network-hdd"
    }
  }

  network_interface {
    subnet_id          = yandex_vpc_subnet.subnet_private.id
    nat                = false
    security_group_ids = [yandex_vpc_security_group.sg_private.id]
  }

  metadata = {
    ssh-keys = "ubuntu:${file(var.ssh_public_key_path)}"
  }

  # Установка Nginx через remote-exec (использует NAT Gateway для доступа в интернет)
  provisioner "remote-exec" {
    inline = [
      "echo 'Starting Nginx installation on private VM...'",
      "sudo apt-get update -y",
      "sudo apt-get install -y nginx",
      "sudo systemctl enable nginx",
      "sudo systemctl start nginx",
      "echo 'Nginx installed successfully on private VM!'",
      "curl -s http://localhost | head -5"
    ]

    connection {
      type        = "ssh"
      user        = "ubuntu"
      private_key = file(var.ssh_private_key_path)
      host        = self.network_interface[0].ip_address
      # Для доступа к приватной ВМ нужен bastion-хост или VPN
      # Если у вас нет доступа к приватной сети, используйте:
      # bastion_host = yandex_compute_instance.vm_public.network_interface[0].nat_ip_address
      # bastion_user = "ubuntu"
      # bastion_private_key = file(var.ssh_private_key_path)
    }
  }

  depends_on = [
    yandex_vpc_subnet.subnet_private,
    yandex_vpc_gateway.nat_gateway
  ]
}