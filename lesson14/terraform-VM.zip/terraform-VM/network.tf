resource "yandex_vpc_network" "vpc_public" {
  name        = "vpc-public"
  description = "Public VPC network"
}

resource "yandex_vpc_subnet" "subnet_public" {
  name           = "subnet-public"
  description    = "Public subnet"
  zone           = var.default_zone
  network_id     = yandex_vpc_network.vpc_public.id
  v4_cidr_blocks = ["192.168.10.0/24"]
}



resource "yandex_vpc_network" "vpc_private" {
  name        = "vpc-private"
  description = "Private VPC network"
}


resource "yandex_vpc_gateway" "nat_gateway" {
  name        = "nat-gateway"
  description = "NAT gateway for private subnet"
  shared_egress_gateway {}
}


resource "yandex_vpc_route_table" "private_route" {
  name        = "private-route-table"
  description = "Route table for private subnet via NAT"
  network_id  = yandex_vpc_network.vpc_private.id

  static_route {
    destination_prefix = "0.0.0.0/0"
    gateway_id         = yandex_vpc_gateway.nat_gateway.id
  }
}


resource "yandex_vpc_subnet" "subnet_private" {
  name           = "subnet-private"
  description    = "Private subnet with NAT"
  zone           = var.default_zone
  network_id     = yandex_vpc_network.vpc_private.id
  v4_cidr_blocks = ["10.10.0.0/24"]
  route_table_id = yandex_vpc_route_table.private_route.id
}


resource "yandex_vpc_security_group" "sg_public" {
  name        = "sg-public"
  description = "Security group for public VM: SSH and HTTP/HTTPS"
  network_id  = yandex_vpc_network.vpc_public.id

  ingress {
    description    = "SSH from anywhere"
    protocol       = "TCP"
    v4_cidr_blocks = ["0.0.0.0/0"]
    port           = 22
  }

  ingress {
    description    = "HTTP from anywhere"
    protocol       = "TCP"
    v4_cidr_blocks = ["0.0.0.0/0"]
    port           = 80
  }

  ingress {
    description    = "HTTPS from anywhere"
    protocol       = "TCP"
    v4_cidr_blocks = ["0.0.0.0/0"]
    port           = 443
  }

  egress {
    description    = "Allow all outgoing"
    protocol       = "ANY"
    v4_cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "yandex_vpc_security_group" "sg_private" {
  name        = "sg-private"
  description = "Security group for private VM: SSH and 8080"
  network_id  = yandex_vpc_network.vpc_private.id

  ingress {
    description    = "SSH from anywhere"
    protocol       = "TCP"
    v4_cidr_blocks = ["0.0.0.0/0"]
    port           = 22
  }

  ingress {
    description    = "Port 8080 from anywhere"
    protocol       = "TCP"
    v4_cidr_blocks = ["0.0.0.0/0"]
    port           = 8080
  }

  egress {
    description    = "Allow all outgoing"
    protocol       = "ANY"
    v4_cidr_blocks = ["0.0.0.0/0"]
  }
}