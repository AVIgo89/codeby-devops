# This file is maintained automatically by "terraform init".
# Manual edits may be lost in future updates.

provider "registry.terraform.io/yandex-cloud/yandex" {
  version     = "0.222.0"
  constraints = "~> 0.130"
  hashes = [
    "h1:yOxFkXZdJtdgoq8wA2TqVtnIMcO57aIop10sAIPuks4=",
  ]
}
