terraform {
  required_providers {
    yandex = {
      source  = "yandex-cloud/yandex"
      version = "~> 0.222"
    }
  }
}

provider "yandex" {
  token     = var.yc_token
  cloud_id  = var.yc_cloud_id
  folder_id = var.yc_folder_id
}

module "subnet_data" {
  source = "../modules/data-subnets"

  network_id   = var.network_id
  yc_token     = var.yc_token
  yc_cloud_id  = var.yc_cloud_id
  yc_folder_id = var.yc_folder_id
}

module "vm_instance" {
  source = "../modules/vm-instance"

  instance_name       = var.instance_name
  zone                = var.vm_zone
  image_id            = var.image_id
  cores               = var.cores
  memory              = var.memory
  disk_size           = var.disk_size
  ssh_public_key_path = var.ssh_public_key_path
  subnet_ids_by_zone  = module.subnet_data.subnets_by_zone

  yc_token     = var.yc_token
  yc_cloud_id  = var.yc_cloud_id
  yc_folder_id = var.yc_folder_id
}

output "all_subnets" {
  value = module.subnet_data.subnet_ids
}

output "subnets_by_zone" {
  value = module.subnet_data.subnets_by_zone
}

output "vm_info" {
  value = {
    id        = module.vm_instance.instance_id
    name      = module.vm_instance.instance_name
    zone      = module.vm_instance.instance_zone
    public_ip = module.vm_instance.instance_public_ip
    subnet    = module.vm_instance.subnet_used
    status    = module.vm_instance.status_message
  }
}
