variable "yc_token" {
  description = "Yandex Cloud OAuth token"
  type        = string
  sensitive   = true
}

variable "yc_cloud_id" {
  description = "Yandex Cloud ID"
  type        = string
}

variable "yc_folder_id" {
  description = "Yandex Cloud Folder ID"
  type        = string
}

variable "network_id" {
  description = "ID сети VPC"
  type        = string
}

variable "instance_name" {
  description = "Имя виртуальной машины"
  type        = string
  default     = "my-module-vm"
}

variable "vm_zone" {
  description = "Зона для создания ВМ"
  type        = string
  default     = "ru-central1-a"
}

variable "image_id" {
  description = "ID образа ОС"
  type        = string
  default     = "fd80d6a7v6j5jo0mq7fn"
}

variable "cores" {
  description = "Количество ядер CPU"
  type        = number
  default     = 2
}

variable "memory" {
  description = "Объем RAM в ГБ"
  type        = number
  default     = 4
}

variable "disk_size" {
  description = "Размер диска в ГБ"
  type        = number
  default     = 20
}

variable "ssh_public_key_path" {
  description = "Путь к публичному SSH ключу"
  type        = string
  default     = "~/.ssh/id_rsa.pub"
}
