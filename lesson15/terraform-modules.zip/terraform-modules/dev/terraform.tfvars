yc_token            = "t1.9euelZqQio-Vk8eVk5iSlpzIyJWQmu3rnpWanZCbjI6LyM6OkseUnZ6Kicjl8_d6AjUr-e90eUl9_d3z9zoxMiv573R5SX391eL17Iac0ZCeiouX0Y-KnZOWnNKMm5Tt-ZCPmpGWm83n9euelZrIjYvJlMjOlcfOmsfOyZnOiu_8xeuelZrIjYvJlMjOlcfOmsfOyZnOir3rnpWam8jGzZaSlZTHyImPjpyNz5a164ac0ZaektGQj5qRlpvSjJqNiZqN.XZkOsuIZSN7QKCxs5s99S_e2kDHcfKjnyfeWpnQAuWW3ATpYeif3xKtAF4wM_yknW6pEANULHhiDPKBmbzqCAA"
yc_cloud_id         = "b1gt3usjmb55lkrnsaht"
yc_folder_id        = "b1gnn6lt5mngnvf1vrlq"
network_id          = "enpc4ioo7ka76j83tfa0"
instance_name       = "my-module-vm"
vm_zone             = "ru-central1-a"
image_id = "fd8m5r8h5r8v7n5q8m5n"
cores               = 2
memory              = 4
disk_size           = 20
ssh_public_key_path = "~/.ssh/id_rsa.pub"



