﻿terraform {
  required_providers {
    yandex = {
      source = "yandex-cloud/yandex"
    }
  }
}

provider "yandex" {
  token     = var.yc_token
  cloud_id  = var.yc_cloud_id
  folder_id = var.yc_folder_id
}

locals {
  selected_subnet_id = var.subnet_ids_by_zone[var.zone][0]
  subnet_exists = contains(keys(var.subnet_ids_by_zone), var.zone)
}

# Ищем актуальный образ Ubuntu
data "yandex_compute_image" "ubuntu" {
  family = "ubuntu-2204-lts"
}

resource "yandex_compute_instance" "vm" {
  count = local.subnet_exists ? 1 : 0
  
  name        = var.instance_name
  zone        = var.zone
  platform_id = "standard-v3"
  
  resources {
    cores  = var.cores
    memory = var.memory
  }
  
  boot_disk {
    initialize_params {
      image_id = data.yandex_compute_image.ubuntu.id
      size     = var.disk_size
    }
  }
  
  network_interface {
    subnet_id = local.selected_subnet_id
    nat       = true
  }
  
  metadata = {
    ssh-keys = "ubuntu:${file(var.ssh_public_key_path)}"
  }
}

output "instance_id" {
  description = "ID созданной ВМ"
  value = try(yandex_compute_instance.vm[0].id, null)
}

output "instance_name" {
  description = "Имя созданной ВМ"
  value = try(yandex_compute_instance.vm[0].name, null)
}

output "instance_zone" {
  description = "Зона созданной ВМ"
  value = try(yandex_compute_instance.vm[0].zone, null)
}

output "instance_public_ip" {
  description = "Публичный IP адрес ВМ"
  value = try(yandex_compute_instance.vm[0].network_interface[0].nat_ip_address, null)
}

output "subnet_used" {
  description = "ID подсети, использованной для ВМ"
  value = try(local.selected_subnet_id, null)
}

output "status_message" {
  description = "Статус создания ВМ"
  value = local.subnet_exists ? "ВМ создана в зоне ${var.zone}" : "ОШИБКА: В зоне ${var.zone} нет подсетей!"
}
