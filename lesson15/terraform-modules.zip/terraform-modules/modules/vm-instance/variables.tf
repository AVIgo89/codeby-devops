﻿variable "instance_name" {
  description = "Имя виртуальной машины"
  type        = string
}

variable "zone" {
  description = "Зона размещения ВМ"
  type        = string
}

variable "image_id" {
  description = "ID образа ОС"
  type        = string
}

variable "cores" {
  description = "Количество ядер CPU"
  type        = number
  default     = 2
}

variable "memory" {
  description = "Объем RAM в ГБ"
  type        = number
  default     = 4
}

variable "disk_size" {
  description = "Размер диска в ГБ"
  type        = number
  default     = 20
}

variable "ssh_public_key_path" {
  description = "Путь к публичному SSH ключу"
  type        = string
}

variable "subnet_ids_by_zone" {
  description = "Map подсетей по зонам"
  type        = map(list(string))
}

variable "yc_token" {
  description = "Yandex Cloud OAuth token"
  type        = string
  sensitive   = true
}

variable "yc_cloud_id" {
  description = "Yandex Cloud ID"
  type        = string
}

variable "yc_folder_id" {
  description = "Yandex Cloud Folder ID"
  type        = string
}
