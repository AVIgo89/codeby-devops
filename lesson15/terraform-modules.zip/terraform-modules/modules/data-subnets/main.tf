﻿terraform {
  required_providers {
    yandex = {
      source = "yandex-cloud/yandex"
    }
  }
}

provider "yandex" {
  token     = var.yc_token
  cloud_id  = var.yc_cloud_id
  folder_id = var.yc_folder_id
}

data "yandex_vpc_network" "selected" {
  network_id = var.network_id
}

data "yandex_vpc_subnet" "all_subnets" {
  for_each = toset(data.yandex_vpc_network.selected.subnet_ids)
  subnet_id = each.value
}

output "subnet_ids" {
  description = "Список ID всех подсетей в VPC"
  value = [for s in data.yandex_vpc_subnet.all_subnets : s.id]
}

output "subnet_zones" {
  description = "Список зон всех подсетей"
  value = {
    for k, v in data.yandex_vpc_subnet.all_subnets : k => v.zone
  }
}

output "subnets_by_zone" {
  description = "одсети сгруппированные по зонам"
  value = {
    for s in data.yandex_vpc_subnet.all_subnets : s.zone => s.id...
  }
}

output "vpc_id" {
  description = "ID VPC сети"
  value = data.yandex_vpc_network.selected.id
}
