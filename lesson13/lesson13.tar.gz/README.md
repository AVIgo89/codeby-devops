- Ansible >= 2.9
- Python >= 3.6
- Target: CentOS 7/8/9 or Ubuntu 18.04/20.04/22.04


1. Install collections:
```bash
ansible-galaxy collection install -r requirements.yml
